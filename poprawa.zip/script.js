const form = document.getElementById('form');
const totalEl = document.getElementById('total');
const addons = document.querySelectorAll('.addon');
const nameInput = document.getElementById('name');
const dateInput = document.getElementById('date');

function updateTotal() {
  let total = 100; 
  addons.forEach(a => {
    if (a.checked) total += parseInt(a.dataset.price);
  });
  totalEl.textContent = total;
}

addons.forEach(addon => addon.addEventListener('change', updateTotal));

form.addEventListener('submit', (e) => {
  const today = new Date().toISOString().split("T")[0];
  if (dateInput.value < today) {
    alert("Data nie może być wcześniejsza niż dziś.");
    e.preventDefault();
    return;
  }
  if (nameInput.value.trim().length < 2) {
    alert("Nazwisko musi mieć co najmniej 2 znaki.");
    e.preventDefault();
    return;
  }
});

updateTotal(); 
